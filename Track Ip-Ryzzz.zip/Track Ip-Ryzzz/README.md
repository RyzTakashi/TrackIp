# TrackIp


![alt text](https://github.com/RyzzzXgans/TrackIp/blob/master/logo.png)

## Install on Termux

<pre>
1. pkg install nodejs git nano
2. npm install --save request colors readline
4. git clone https://github.com/RyzzzXgans/TrackIp
5. cd TrackIp
6. node find
</pre>

## Run this tools

<pre>
node find
</pre>
